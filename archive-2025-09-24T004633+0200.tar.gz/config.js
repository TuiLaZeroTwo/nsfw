module.exports = {
  token: "MzM5ODMxMTc2NzYyMDk3NjY0.GXqsCz.UFoLTBhcZSEaWqoMB-4NW_HeitNkpVhTsXvDyA", //put your token here
  ownerID: "339831176762097664",// put your user id here
  prefix: "-", // your prefix, can be anything you want
  snipe: {
    enabled: false,
  },
  gen: {
    enabled: false,
  },
  userinfo: {
    enabled: true,
  },
  help: {
    enabled: true, 
  },
  ping: {
    enabled: true,
  },
  clear: {
    enabled: false,
  },
  hoststatus: {
    enabled: true,
  },
  rotatestatus: {
    enabled: true,
    interval: 8000, // 10 seconds
    emoji: {
      "0": "<a:05_blue_cat_love:1140998023699255296>",
      "1": "<a:frog_love:981600892472160286>",
      "2": "<a:Meow:811763728185950239>",
      "3": "<:nodejs:1287762938576506891>",
      "4": "<a:warningbug:905560995886411806>",
      "5": "<a:angry_bongos:777938877641129996>",
      "6": "<:Tiktok:1106194421013303397>",
      "7": "<:as_youtube_icon:1313123197582970880>",
      "8": "<:altare:1415667527320600699>",
      "9": "<:Freefire:1325733067230543923>",
      "10": "<a:lofi_chill_animated:1269734916074111138>",
      "11": "<:Huh:811763364974821417> "
    },
    message: {
      "0": "i love lan thi",
      "1": "fall in love with cat/ntwlie",
      "2": ".gg/tlz",
      "3": "nodejs lover",
      "4": "fvcking bugs",
      "5": "dont mess with me duh",
      "6": "tlz.long",
      "7": "sub pls",
      "8": "ty altr.cc for hosting",
      "9": "free fire!",
      "10": "lowkey asf",
      "11": "wat da heo",
    },
  },
  rpc: {
    enabled: true,
    mode: "rpc", // "weather", "rpc", "none"
    name: "tlz's life",
    url: "https://twitch.tv/tlzytb",
    type: 0,
    application_id: "1204053320629624893", // you can skip this
    client_id: "1204053320629624893", // idk wtf to do with this
    details: "like a hardcore games",
    state: "take it or leave it",
    large_image: "https://cdn.discordapp.com/guilds/1395017806788952094/users/339831176762097664/avatars/152e7470b4c84d211c16ff18c88b4201.png", //only link because im fixing the app id
    large_image_text: "Cool huh",
    small_image: "https://cdn.discordapp.com/avatars/339831176762097664/f8204747043c075a9a8e9a2375565330.png?size=512",  //only link because im fixing the app id
    small_image_text: "Powered by tlz",
    buttons: {
      name1: "Youtube",
      url1: "https://youtube.com/TLZITSME",
      name2: "GitHub Profile",
      url2: "https://github.com/tuilazerotwo"
    }
  },
  qr: {
    enabled: true,
    addrinfo: "hhlong209",
    bankid: "970422",
    style: "compact2",
    accountname: "HUYNH HUU LONG"
  },
  voice: {
    enabled: false,
    channel_id: "1391926171251380305", //put your voice channel id here
    self_deaf: false,
    self_mute: true
  },
  auto_react: {
    enabled: false,
    reactions: {
      "1215484798269923399": ["🔥", "❤️"],
      "1368980718893662258": ["🔥", "❤️"]
    }
  }
};