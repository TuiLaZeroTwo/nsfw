import { fork } from 'child_process';
import * as readline from 'readline';
import { readFileSync } from 'fs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const options = [
    { name: 'Ore Bots', script: './modules/ore.js', type: 'ore', selected: false },
    { name: 'Crate Bots', script: './modules/crate.js', type: 'crate', selected: false },
    { name: 'Mob AFK Bots', script: './modules/mob-afk.js', type: 'mobs', selected: false },
    { name: 'Trade Bots', script: './modules/trade.js', type: 'trade', selected: false },
    { name: 'All Bots', fn: () => {
        options.slice(0, -1).forEach(opt => opt.selected = true);
    }, selected: false }
];

let currentIndex = 0;
const childProcesses = new Map();

function renderMenu() {
    console.clear();
    console.log('Select bot scripts to run (Space to toggle, Enter to execute):\n');
    options.forEach((option, index) => {
        const marker = index === currentIndex ? '>' : ' ';
        const selected = option.selected ? '[X]' : '[ ]';
        console.log(`${marker} ${selected} ${option.name}`);
    });
}

async function startBotProcesses(type, accounts, script) {
    for (const account of accounts) {
        const child = fork(script, [JSON.stringify(account)]);
        childProcesses.set(`${type}-${account.username}`, child);
        console.log(`Started ${type} bot for ${account.username}`);
        await sleep(5000);
    }
}

async function handleInput(key) {
    if (key === ' ') {
        options[currentIndex].selected = !options[currentIndex].selected;
        if (currentIndex === options.length - 1) {
            options.slice(0, -1).forEach(opt => opt.selected = options[options.length - 1].selected);
        } else if (options.slice(0, -1).every(opt => opt.selected)) {
            options[options.length - 1].selected = true;
        } else {
            options[options.length - 1].selected = false;
        }
    } else if (key === '\x1B[A') {
        currentIndex = currentIndex === 0 ? options.length - 1 : currentIndex - 1;
    } else if (key === '\x1B[B') {
        currentIndex = (currentIndex + 1) % options.length;
    } else if (key === '\r') {
        console.clear();
        rl.close();
        const selectedOptions = options.filter(opt => opt.selected && opt.script);
        if (selectedOptions.length === 0) {
            console.log('No options selected. Exiting.');
            process.exit(0);
        }

        let accountsData;
        try {
            accountsData = JSON.parse(readFileSync('./data/accounts.json'));
        } catch (error) {
            console.error("Failed to load accounts from accounts.json:", error);
            process.exit(1);
        }

        try {
            for (const option of selectedOptions) {
                console.log(`Starting ${option.name} in separate processes...`);
                if (accountsData[option.type]) {
                    await startBotProcesses(option.type, accountsData[option.type].accounts, option.script);
                } else {
                    console.error(`No accounts found for ${option.type}`);
                }
            }
            console.log('All selected bot processes started.');
        } catch (err) {
            console.error('Error starting bot processes:', err);
        }
    }
    renderMenu();
}

async function main() {
    renderMenu();
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');

    process.stdin.on('data', async (key) => {
        if (key === '\x03') {
            console.log('Terminating all child processes...');
            childProcesses.forEach((child, name) => {
                console.log(`Terminating ${name}...`);
                child.kill();
            });
            rl.close();
            process.exit(0);
        }
        await handleInput(key);
    });
}

main();