import { createBot } from 'mineflayer';
import { readFileSync } from 'fs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function joinGame(bot) {
    await sleep(2000);
    bot.setQuickBarSlot(4);
    bot.activateItem();
}

async function startBot(account, reconnectDelay = 5000) {
    const bot = await createBot({
        version: '1.12.2',
        username: account.username,
        auth: 'offline',
        host: 'aemine.vn',
    });

    bot.accountPassword = account.password;
    let hasConvertedDiamond = false;
    let isDigging = false;
    let isConverting = false;
    let isSelling = false;
    let isTransferring = false;
    let lastDigTime = Date.now();

    async function dig() {
        if (isConverting || isSelling || isTransferring) {
            setTimeout(dig, 100);
            return;
        }
        isDigging = true;
        try {
            const block = bot.blockAtCursor(5);
            if (!block) {
                setTimeout(dig, 100);
                return;
            }
            const digDelay = Math.random() * (1000 - 550) + 550;
            await sleep(digDelay);
            const now = Date.now();
            if (now - lastDigTime < 100) {
                await sleep(100 - (now - lastDigTime));
            }
            await bot.dig(block, 'ignore', 'raycast');
            lastDigTime = Date.now();
            dig();
        } catch (err) {
            setTimeout(dig, 100);
            isDigging = false;
        }
    }

    async function startConvert() {
        if (isConverting || isSelling || isTransferring) return;
        isConverting = true;
        isDigging = false;
        console.log(`[${account.username}] Starting conversion process`);
        bot.chat('/kho');
        await sleep(5000);
        isConverting = false;
        console.log(`[${account.username}] Conversion process completed, resuming digging`);
        if (!isTransferring && !isSelling) {
            isDigging = true;
            dig();
        }
    }

    async function startSell() {
        if (isConverting || isSelling || isTransferring) return;
        isSelling = true;
        isDigging = false;
        console.log(`[${account.username}] Starting sell process`);
        bot.chat('/kho'); 
        
        await new Promise((resolve) => {
            const onWindowOpen = async (window) => {
                if (window.title === `{"text":"§0Kho Khoáng Sản | §a${account.username}"}`) {
                    try {
                        await bot.clickWindow(10, 0, 0);
                        await sleep(1000);
                        await bot.clickWindow(13, 1, 0);
                        await sleep(1000);
                        await bot.clickWindow(12, 0, 0);
                        await sleep(1000);
                        await bot.clickWindow(13, 1, 0);
                        await sleep(1000);
                        await bot.clickWindow(22, 0, 0);
                        await sleep(1000);
                        await bot.clickWindow(13, 1, 0);
                        console.log(`[${account.username}] Sell process completed`);
                        bot.removeListener('windowOpen', onWindowOpen);
                        resolve();
                    } catch (err) {
                        console.error(`[${account.username}] Sell window click error: ${err.message}`);
                        bot.removeListener('windowOpen', onWindowOpen);
                        resolve();
                    }
                }
            };
            bot.on('windowOpen', onWindowOpen);
            setTimeout(() => {
                bot.removeListener('windowOpen', onWindowOpen);
                resolve();
            }, 10000);
        });

        isSelling = false;
        if (!isConverting && !isTransferring) {
            isDigging = true;
            dig();
        }
    }

    async function startTransfer() {
        if (isConverting || isSelling || isTransferring) return;
        isTransferring = true;
        isDigging = false;
        const transferTarget = ['KarenDayLing', 'FatherHoa','MyItemPro', 'KingPhoenix','MyItemNoob', 'ToiKhongPhaiGay','ToiKhongPhaiGay1', 'ToiKhongPhaiGay2','KhoangSanPro', 'KhoangSanPro1','KhoangSanPro2'].includes(account.username) ? 'MS_Ling' : 'TuiLaZeroTwo';
        console.log(`[${account.username}] Starting transfer process to ${transferTarget}`);
        bot.chat(`/kho transfer multi KareniaKaen`);
        await sleep(5000);
        isTransferring = false;
        console.log(`[${account.username}] Transfer process completed, resuming digging`);
        if (!isConverting && !isSelling) {
            isDigging = true;
            dig();
        }
    }

    bot.on('messagestr', async (message) => {
        console.log(`[${account.username}]: ${message}`);
        if (message.includes('Đăng ký mở chat gõ lệnh')) {
            bot.chat(`/DK ${bot.accountPassword}`);
            return;
        }
        if (message.includes('hãy đăng nhập bằng lệnh')) {
            console.log(`[${account.username}] Logging in with password.`);
            bot.chat(`/DN ${bot.accountPassword}`);
            return;
        }
        if (message.includes('Bạn không có thư mới.')) {
            bot.chat('/home');
            console.log(`[${account.username}] Logged and started mining`);
            dig();
            return;
        }
        if (message.includes('arhgjarhloarhoakharhargarfwdawd')) {
            startConvert();
            return;
        }
        if (message.includes('ahratrnmatmntnmtastonjokhokrh')) {
            startTransfer();
            return;
        }
        if (message.includes('Đăng nhập thành công!')) {
            console.log(`[${account.username}] Login successful!`);
            await joinGame(bot);
            return;
        }
    });

    bot.on('windowOpen', async (window) => {
        console.log(`[${account.username}] Window opened: ${window.title}`);
        await sleep(2000);

        try {
            if (window.title === '{"text":"§e§lＡｅｍｉｎｅ.ｖｎ§r"}') {
                await bot.clickWindow(20, 0, 0);
                return;
            }
            if (window.title === '{"text":"§8Game Menu ︱ §c§lAE§f§lMINE.VN"}') {
                await bot.clickWindow(15, 0, 0);
                return;
            }
            if (window.title === '{"text":"§4§lKits"}') {
                await bot.clickWindow(20, 0, 0);
                return;
            }
            if (window.title === `{"text":"§0Kho Khoáng Sản | §a${account.username}"}`) {
                if (isConverting) {
                    await bot.clickWindow(39, 0, 0);
                    return;
                }
                if (isSelling) {
                    return;
                }
                return;
            }
            if (window.title === `{"text":"§0Chuyển tài nguyên | §aKareniaKaen"}`) {
                try {
                    const blocksToToss = ['iron_block', 'gold_block', 'diamond_block'];
                    
                    for (const blockType of blocksToToss) {
                        const item = window.slots.find(slot => slot && slot.name === blockType);
                        if (item) {
                            await bot.clickWindow(item.slot, 0, 4);
                            console.log(`[${account.username}] Tossed 1 ${blockType} to MS_Ling from chest slot ${item.slot}`);
                            await sleep(500);
                        } else {
                            console.log(`[${account.username}] No ${blockType} found in chest window`);
                        }
                    }

                    await bot.clickWindow(40, 0, 0);
                    console.log(`[${account.username}] Confirmed transfer to MS_Ling`);
                    await sleep(2000);
                } catch (error) {
                    console.error(`[${account.username}] Error tossing blocks to MS_Ling: ${error}`);
                }
                return;
            }
            if (window.title === `{"text":"§0Chuyển tài nguyên | §aTuiLaZeroTwo"}`) {
                try {
                    const blocksToToss = ['iron_block', 'gold_block', 'diamond_block', 'emerald_block', 'redstone_block'];
                    
                    for (const blockType of blocksToToss) {
                        const item = window.slots.find(slot => slot && slot.name === blockType);
                        if (item) {
                            await bot.clickWindow(item.slot, 0, 4);
                            console.log(`[${account.username}] Tossed 1 ${blockType} to TuiLaZeroTwo from chest slot ${item.slot}`);
                            await sleep(500);
                        } else {
                            console.log(`[${account.username}] No ${blockType} found in chest window`);
                        }
                    }

                    await bot.clickWindow(40, 0, 0);
                    console.log(`[${account.username}] Confirmed transfer to TuiLaZeroTwo`);
                    await sleep(2000);
                } catch (error) {
                    console.error(`[${account.username}] Error tossing blocks to TuiLaZeroTwo: ${error}`);
                }
                return;
            }
            if (window.title === `{"text":"§0Convert Tài Nguyên | §a${account.username}"}`) {
                if (!hasConvertedDiamond) {
                    await bot.clickWindow(12, 0, 0);
                    console.log(`[${account.username}] Converting Kim Cương`);
                    await sleep(1000);
                    await bot.clickWindow(10, 0, 0);
                    hasConvertedDiamond = true;
                    await sleep(1000);
                    await bot.clickWindow(22, 0, 0);
                    await sleep(1000);
                    await bot.clickWindow(14, 0, 0);
                    await sleep(1000);
                    await bot.clickWindow(10, 0, 0);
                    console.log(`[${account.username}] Converting Emerald`);
                    return;
                }
                hasConvertedDiamond = false;
                await bot.clickWindow(12, 0, 0);
                console.log(`[${account.username}] Restarting conversion cycle`);
                return;
            }
        } catch (err) {
            console.error(`[${account.username}] Window click error: ${err.message}`);
            if (err.message.includes("Server didn't respond to transaction")) {
                console.log(`[${account.username}] Reconnecting due to transaction error...`);
                bot.quit();
                return;
            }
            throw err;
        }
    });

    bot.on('spawn', () => {
        console.log(`[${account.username}] Bot spawned.`);
    });

    bot.on('error', (err) => {
        console.error(`[${account.username}] Bot error:`, err);
    });

    bot.on('end', async (reason) => {
        console.log(`[${account.username}] Bot disconnected: ${reason}`);
        console.log(`[${account.username}] Attempting to reconnect in ${reconnectDelay / 1000} seconds...`);
        isDigging = false;
        isConverting = false;
        isSelling = false;
        isTransferring = false;
        hasConvertedDiamond = false;
        await sleep(reconnectDelay);
        startBot(account, reconnectDelay);
    });
}

async function main() {
    const account = JSON.parse(process.argv[2]);
    await startBot(account);
}

main();