import { createBot } from 'mineflayer';
import { readFileSync } from 'fs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function joinGame(bot) {
    await sleep(2000);
    bot.setQuickBarSlot(4);
    bot.activateItem();
}

async function startBotForAccount(account, reconnectDelay = 5000) {
    const bot = await createBot({
        version: '1.12.2',
        username: account.username,
        auth: 'offline',
        host: 'aemine.vn',
    });

    bot.accountPassword = account.password;
    let fixcrateInterval;

    bot.on('messagestr', async (message) => {
        console.log(`[${account.username}]: ${message}`);
        if (message.includes('Đăng ký mở chat gõ lệnh')) {
            bot.chat(`/DK ${bot.accountPassword}`);
            return;
        }
        if (message.includes('hãy đăng nhập bằng lệnh')) {
            console.log(`[${account.username}] Logging in with password.`);
            bot.chat(`/DN ${bot.accountPassword}`);
            return;
        }
        if (message.includes('fix crate di em')) {
            bot.chat(`/fixcrate`);
            return;
        }
        if (message.includes('Bạn không có thư mới.')) {
            bot.chat('/home');
    
            const maxDistance = 2;
            const enderChest = bot.findBlock({
                matching: (block) => block.name === "ender_chest",
                maxDistance: maxDistance
            });

            if (!enderChest) {
                console.log("No ender chest found nearby!");
                return;
            }

            try {
                await bot.lookAt(enderChest.position.offset(0.5, 0.5, 0.5));
            } catch (err) {
                console.error(`Failed to look at ender chest: ${err.message}`);
                return;
            }

            while (true) {
                try {
                    await bot.activateBlock(enderChest);
                    await sleep(1000);
                } catch (err) {
                    console.error(`Failed to activate ender chest: ${err.message}`);
                    break;
                }
            }
        }
        if (message.includes('coop tui')) {
            bot.chat(`/island coop ${account.username}`);
            return;
        }
        if (message.includes('Đăng nhập thành công!')) {
            console.log(`[${account.username}] Login successful!`);
            await joinGame(bot);
            return;
        }
    });

    bot.on('windowOpen', async (window) => {
        console.log(`[${account.username}] Window opened: ${window.title}`);
        await sleep(2000);
        
        if (window.title === '{"text":"§4§lKits"}') {
            await bot.clickWindow(20, 0, 0);
            return;
        }
        if (window.title === '{"text":"§e§lＡｅｍｉｎｅ.ｖｎ§r"}') {
            await bot.clickWindow(20, 0, 0);
            return;
        }
        if (window.title === '{"text":"§8Game Menu ︱ §c§lAE§f§lMINE.VN"}') {
            await bot.clickWindow(15, 0, 0);
            return;
        }
    });

    bot.on('spawn', () => {
        console.log(`[${account.username}] Bot spawned.`);
        fixcrateInterval = setInterval(async () => {
            console.log(`[${account.username}] Scheduled fixcrate every 15 minutes.`);
            bot.chat('/fixcrate');
        }, 7 * 60 * 1000);
    });

    bot.on('error', (err) => {
        console.error(`[${account.username}] Bot error:`, err);
    });

    bot.on('end', async (reason) => {
        console.log(`[${account.username}] Bot disconnected: ${reason}`);
        clearInterval(fixcrateInterval);
        console.log(`[${account.username}] Attempting to reconnect in ${reconnectDelay / 1000} seconds...`);
        await sleep(reconnectDelay);
        startBotForAccount(account, reconnectDelay);
    });
}

async function main() {
    const account = JSON.parse(process.argv[2]);
    await startBotForAccount(account);
}

main();