import { createBot } from 'mineflayer';
import { readFileSync } from 'fs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function joinGame(bot) {
    await sleep(2000);
    bot.setQuickBarSlot(4);
    bot.activateItem();
}

async function startBot(account, reconnectDelay = 5000) {
    const bot = await createBot({
        version: '1.12.2',
        username: account.username,
        auth: 'offline',
        host: 'aemine.vn',
    });

    bot.accountPassword = account.password;

    bot.on('messagestr', async (message) => {
        console.log(`[${account.username}]: ${message}`);        
        const allowedPrefix = '[Discord | Quân Đoàn Chó]';
        const kickPhrase = `out ${account.username}`;

        if (message.startsWith(allowedPrefix)) {
            const content = message.substring(allowedPrefix.length).trim();
            
            if (content.toLowerCase().includes(kickPhrase.toLowerCase())) {
                console.log(`[${account.username}] Authorized kick command received from ${allowedPrefix}: "${message}". Quitting account.`);
                bot.quit('Kicked by authorized command.'); 
                return; 
            }
        }
        if (message.includes('Đăng ký mở chat gõ lệnh')) {
            bot.chat(`/DK ${bot.accountPassword}`);
            return;
        }
        if (message.includes('hãy đăng nhập bằng lệnh')) {
            console.log(`[${account.username}] Logging in with password.`);
            bot.chat(`/DN ${bot.accountPassword}`);
            return;
        }
        if (message.includes('Bạn không có thư mới.')) {
            bot.chat('/home');
            await sleep(1000);
            bot.chat('/sit');
            return;
        }
        if (message.includes('coop tui')) {
            bot.chat(`/island coop ${account.username}`);
            return;
        }
        if (message.includes('Đăng nhập thành công!')) {
            console.log(`[${account.username}] Login successful!`);
            await joinGame(bot);
            return;
        }
    });

    bot.on('windowOpen', async (window) => {
        console.log(`[${account.username}] Window opened: ${window.title}`);
        await sleep(2000);

        if (window.title === '{"text":"§e§lＡｅｍｉｎｅ.ｖｎ§r"}') {
            await bot.clickWindow(20, 0, 0);
            return;
        }
        if (window.title === '{"text":"§8Game Menu ︱ §c§lAE§f§lMINE.VN"}') {
            await bot.clickWindow(15, 0, 0);
            return;
        }
        if (window.title === '{"text":"§4§lKits"}') {
            await bot.clickWindow(20, 0, 0);
            return;
        }
    });

    bot.on('spawn', () => {
        console.log(`[${account.username}] Bot spawned.`);
    });

    bot.on('death', () => {
        console.log(`[${account.username}] Bot died. Attempting to reconnect.`);
        bot.quit();
    });

    bot.on('error', (err) => {
        console.error(`[${account.username}] Bot error:`, err);
    });

    bot.on('end', async (reason) => {
        console.log(`[${account.username}] Bot disconnected: ${reason}`);
        console.log(`[${account.username}] Attempting to reconnect in ${reconnectDelay / 1000} seconds...`);
        
        await sleep(reconnectDelay);
        startBot(account, reconnectDelay);
    });
}

async function main() {
    const account = JSON.parse(process.argv[2]);
    await startBot(account);
}

main();
