import { createBot } from 'mineflayer';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function joinGame(bot) {
    await sleep(2000);
    bot.setQuickBarSlot(4);
    bot.activateItem();
}

function getRandomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function startBotForAccount(account, reconnectDelay = 5000) {
    const bot = await createBot({
        version: '1.12.2',
        username: account.username,
        auth: 'offline',
        host: 'aemine.vn',
    });

    bot.accountPassword = account.password;
    let repeatCount = 0;
    const maxRepeats = 42;

    bot.on('messagestr', async (message) => {
        console.log(`[${account.username}]: ${message}`);
        if (message.includes('Đăng ký mở chat gõ lệnh')) {
            bot.chat(`/DK ${bot.accountPassword}`);
            return;
        }
        if (message.includes('hãy đăng nhập bằng lệnh')) {
            console.log(`[${account.username}] Logging in with password.`);
            bot.chat(`/DN ${bot.accountPassword}`);
            return;
        }
        if (message.includes('Bạn không có thư mới.')) {
            bot.chat('/home');
            await sleep(2000);
            bot.chat('/shop');
        }
        if (message.includes('Đăng nhập thành công!')) {
            console.log(`[${account.username}] Login successful!`);
            await joinGame(bot);
            return;
        }
    });

    bot.on('windowOpen', async (window) => {
    console.log(`[${account.username}] Window opened: ${window.title}`);
    await sleep(2000);
    
    if (window.title === '{"text":"§e§lＡｅｍｉｎｅ.ｖｎ§r"}') {
        await bot.clickWindow(20, 0, 0);
        return;
    }
    if (window.title === '{"text":"§8Game Menu ︱ §c§lAE§f§lMINE.VN"}') {
        await bot.clickWindow(15, 0, 0);
        return;
    }

    if (window.title === '{"text":"§8ItemShop (1/5)"}') {
        console.log(`[${account.username}] Entering ItemShop...`);
        const ironBlock = window.slots.find(item => item && item.name === 'iron_block');
        if (ironBlock) {
            console.log(`[${account.username}] Found iron block at slot ${ironBlock.slot}. Clicking it.`);
            await bot.clickWindow(ironBlock.slot, 0, 0);
        } else {
            console.log(`[${account.username}] Iron block not found in ItemShop. Closing window.`);
            bot.closeWindow(window);
        }
        return;
    }

    if (window.title.startsWith('{"text":"§8ItemShop §8§l→ §8')) {
        console.log(`[${account.username}] Inside item list. Clicking slot 30.`);
        await bot.clickWindow(30, 0, 0);
        bot.closeWindow(window);
        await sleep(getRandomDelay(10000, 20000));
        bot.chat('/kho');
        return;
    }
    
    if (window.title === `{"text":"§0Kho Khoáng Sản | §a${account.username}"}`) {
        console.log(`[${account.username}] Entering Kho Khoáng Sản...`);
        const ironBlock = window.slots.find(item => item && item.name === 'iron_block');
        if (ironBlock) {
            console.log(`[${account.username}] Found iron block at slot ${ironBlock.slot}. Clicking it.`);
            await bot.clickWindow(ironBlock.slot, 0, 0);
        } else {
            console.log(`[${account.username}] Iron block not found in Kho Khoáng Sản. Closing window.`);
            bot.closeWindow(window);
        }
        return;
    }
    
    if (window.title.startsWith('{"text":"§0Vật phẩm §fKhối Sắt | §a') || window.title.startsWith('{"text":"§0Vật phẩm §7Đá Cuội | §a')) {
        console.log(`[${account.username}] Inside item details. Right-clicking slot 10.`);
        await bot.clickWindow(10, 1, 0);
        bot.closeWindow(window);

        repeatCount++;
        if (repeatCount >= maxRepeats) {
            console.log(`[${account.username}] Completed ${maxRepeats} repeats. Initiating transfer.`);
            await sleep(getRandomDelay(10000, 30000));
            bot.chat('/kho transfer multi KareniaKaen');
            repeatCount = 0;
        } else {
            console.log(`[${account.username}] Repeating cycle (${repeatCount}/${maxRepeats}).`);
            await sleep(getRandomDelay(10000, 30000));
            bot.chat('/shop');
        }
        return;
    }
    
    if (window.title === '{"text":"§0Chuyển tài nguyên | §aKareniaKaen"}') {
        try {
            const blocksToToss = ['iron_block'];
            
            for (const blockType of blocksToToss) {
                const item = window.slots.find(slot => slot && slot.name === blockType);
                if (item) {
                    await bot.clickWindow(item.slot, 0, 4);
                    console.log(`[${account.username}] Tossed 1 ${blockType} to KareniaKaen from chest slot ${item.slot}`);
                } else {
                    console.log(`[${account.username}] No ${blockType} found in chest window`);
                }
            }
            await bot.clickWindow(40, 0, 0);
            console.log(`[${account.username}] Confirmed transfer to KareniaKaen`);            
            // Add random delay before sending the next command
            await sleep(getRandomDelay(10000, 30000));
            bot.chat('/shop');
        } catch (error) {
            console.error(`[${account.username}] Error tossing blocks to KareniaKaen: ${error}`);
        }
        return;
    }
    });

    bot.on('spawn', () => {
        console.log(`[${account.username}] Bot spawned.`);
    });

    bot.on('error', (err) => {
        console.error(`[${account.username}] Bot error:`, err);
    });

    bot.on('end', async (reason) => {
        console.log(`[${account.username}] Bot disconnected: ${reason}`);
        console.log(`[${account.username}] Attempting to reconnect in ${reconnectDelay / 1000} seconds...`);
        await sleep(reconnectDelay);
        startBotForAccount(account, reconnectDelay);
    });
}

async function main() {
    const account = JSON.parse(process.argv[2]);
    await startBotForAccount(account);
}

main();